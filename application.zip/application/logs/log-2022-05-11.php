<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-11 04:09:44 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\Software\htdocs\ekattor_7.4\system\libraries\Email.php 1902
ERROR - 2022-05-11 07:53:29 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF) E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 111
ERROR - 2022-05-11 07:53:41 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF) E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 111
ERROR - 2022-05-11 07:54:35 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF) E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 111
ERROR - 2022-05-11 08:09:02 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::group_by() E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 98
ERROR - 2022-05-11 08:09:15 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::group_by() E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 98
ERROR - 2022-05-11 08:12:15 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::distinct() E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 98
ERROR - 2022-05-11 08:12:18 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::distinct() E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 98
ERROR - 2022-05-11 08:12:40 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::distinct() E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 98
ERROR - 2022-05-11 08:12:42 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::distinct() E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 98
