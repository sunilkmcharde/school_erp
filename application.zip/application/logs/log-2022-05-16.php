<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-16 06:13:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 06:18:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 06:18:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 06:19:39 --> 404 Page Not Found: Home/online_admission
ERROR - 2022-05-16 06:25:21 --> 404 Page Not Found: Home/online_admission
ERROR - 2022-05-16 06:33:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 07:17:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 08:11:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 08:45:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 08:48:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 08:48:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 09:17:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 09:18:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 09:18:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 09:20:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 09:51:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 05:53:08 --> Severity: Notice --> Undefined index: educational_qualifications E:\Software\htdocs\ekattor_7.4\application\models\Frontend_model.php 498
ERROR - 2022-05-16 05:53:08 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\models\Frontend_model.php 498
ERROR - 2022-05-16 05:55:14 --> Severity: error --> Exception: Call to undefined method Frontend_model::check_duplication() E:\Software\htdocs\ekattor_7.4\application\models\Frontend_model.php 503
ERROR - 2022-05-16 09:56:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:00:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 06:01:21 --> Severity: error --> Exception: Call to undefined method Crud_model::check_duplication() E:\Software\htdocs\ekattor_7.4\application\models\Frontend_model.php 503
ERROR - 2022-05-16 10:01:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:05:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:05:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 06:06:07 --> Severity: error --> Exception: Call to undefined method Crud_model::check_duplication() E:\Software\htdocs\ekattor_7.4\application\models\Frontend_model.php 504
ERROR - 2022-05-16 10:06:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 06:07:10 --> Severity: error --> Exception: Call to undefined method Crud_model::check_duplication() E:\Software\htdocs\ekattor_7.4\application\models\Frontend_model.php 504
ERROR - 2022-05-16 10:08:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:09:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:10:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:11:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:15:43 --> 404 Page Not Found: Assets/toastr
ERROR - 2022-05-16 10:15:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:16:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:16:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:17:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:17:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:21:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:21:48 --> Severity: error --> Exception: syntax error, unexpected ''message'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' E:\Software\htdocs\ekattor_7.4\application\models\Frontend_model.php 546
ERROR - 2022-05-16 10:23:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 06:24:06 --> Severity: Notice --> Undefined index: educational_qualifications E:\Software\htdocs\ekattor_7.4\application\models\Frontend_model.php 499
ERROR - 2022-05-16 06:24:06 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\models\Frontend_model.php 499
ERROR - 2022-05-16 10:26:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:26:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:27:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 10:28:23 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' E:\Software\htdocs\ekattor_7.4\application\controllers\Login.php 66
ERROR - 2022-05-16 10:28:26 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' E:\Software\htdocs\ekattor_7.4\application\controllers\Login.php 66
ERROR - 2022-05-16 07:31:54 --> Severity: error --> Exception: Call to undefined function active_school() E:\Software\htdocs\ekattor_7.4\application\views\backend\navigation.php 110
ERROR - 2022-05-16 07:32:27 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string E:\Software\htdocs\ekattor_7.4\application\views\backend\navigation.php 110
ERROR - 2022-05-16 11:34:37 --> 404 Page Not Found: Superadmin/online_admission
ERROR - 2022-05-16 11:37:59 --> Severity: Compile Error --> Cannot redeclare Superadmin::about() E:\Software\htdocs\ekattor_7.4\application\controllers\Superadmin.php 1496
ERROR - 2022-05-16 07:38:35 --> Severity: Warning --> include(superadmin/online_admissions/index.php): failed to open stream: No such file or directory E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 07:38:35 --> Severity: Warning --> include(): Failed opening 'superadmin/online_admissions/index.php' for inclusion (include_path='.;C:\php\pear') E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 08:24:12 --> Severity: Warning --> include(superadmin/online_admissions/index.php): failed to open stream: No such file or directory E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 08:24:12 --> Severity: Warning --> include(): Failed opening 'superadmin/online_admissions/index.php' for inclusion (include_path='.;C:\php\pear') E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 08:24:14 --> Severity: Warning --> include(superadmin/online_admissions/index.php): failed to open stream: No such file or directory E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 08:24:14 --> Severity: Warning --> include(): Failed opening 'superadmin/online_admissions/index.php' for inclusion (include_path='.;C:\php\pear') E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 08:29:03 --> Severity: Warning --> include(superadmin/online_admissions/index.php): failed to open stream: No such file or directory E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 08:29:03 --> Severity: Warning --> include(): Failed opening 'superadmin/online_admissions/index.php' for inclusion (include_path='.;C:\php\pear') E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 19:10:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 19:11:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2022-05-16 15:12:36 --> Severity: Warning --> include(superadmin/online_admissions/index.php): failed to open stream: No such file or directory E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 15:12:36 --> Severity: Warning --> include(): Failed opening 'superadmin/online_admissions/index.php' for inclusion (include_path='.;C:\php\pear') E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 15:16:56 --> Severity: Warning --> include(superadmin/online_admissions/index.php): failed to open stream: No such file or directory E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 15:16:56 --> Severity: Warning --> include(): Failed opening 'superadmin/online_admissions/index.php' for inclusion (include_path='.;C:\php\pear') E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 15:17:21 --> Severity: Warning --> include(superadmin/online_admissions/index.php): failed to open stream: No such file or directory E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 15:17:21 --> Severity: Warning --> include(): Failed opening 'superadmin/online_admissions/index.php' for inclusion (include_path='.;C:\php\pear') E:\Software\htdocs\ekattor_7.4\application\views\backend\index.php 40
ERROR - 2022-05-16 15:17:48 --> Severity: Notice --> Undefined variable: class_id E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 15
ERROR - 2022-05-16 15:17:48 --> Severity: Notice --> Undefined variable: section_id E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 15
ERROR - 2022-05-16 15:18:13 --> Severity: Notice --> Undefined variable: class_id E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 15
ERROR - 2022-05-16 15:18:13 --> Severity: Notice --> Undefined variable: section_id E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 15
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 34
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 34
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 36
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 36
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 34
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 34
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 36
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 36
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 34
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 34
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 36
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 36
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 34
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 34
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 36
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 36
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Undefined variable: student E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:26:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 38
ERROR - 2022-05-16 15:30:46 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 3
ERROR - 2022-05-16 15:30:46 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 9
ERROR - 2022-05-16 15:30:46 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 12
ERROR - 2022-05-16 15:30:46 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 16
ERROR - 2022-05-16 15:30:46 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 38
ERROR - 2022-05-16 15:30:46 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 15:30:46 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 15:30:46 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 15:32:44 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 3
ERROR - 2022-05-16 15:32:44 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 9
ERROR - 2022-05-16 15:32:44 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 12
ERROR - 2022-05-16 15:32:44 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 16
ERROR - 2022-05-16 15:32:44 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 38
ERROR - 2022-05-16 15:32:44 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 15:32:44 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 15:32:44 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 15:34:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 3
ERROR - 2022-05-16 15:34:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 9
ERROR - 2022-05-16 15:34:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 12
ERROR - 2022-05-16 15:34:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 16
ERROR - 2022-05-16 15:34:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 38
ERROR - 2022-05-16 15:34:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 15:34:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 15:34:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 15:42:51 --> Severity: Notice --> Undefined variable: class_id E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 15
ERROR - 2022-05-16 15:42:51 --> Severity: Notice --> Undefined variable: section_id E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\online_admission\list.php 15
ERROR - 2022-05-16 15:44:09 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 15:44:09 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 15:44:09 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 15:56:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 68
ERROR - 2022-05-16 15:56:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 74
ERROR - 2022-05-16 15:56:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 80
ERROR - 2022-05-16 16:00:23 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 16:00:23 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 16:00:23 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:00:36 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 16:00:36 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 16:00:36 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:01:18 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 16:01:18 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 16:01:18 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:01:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 16:01:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 16:01:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:04:42 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 16:04:42 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 16:04:42 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:04:47 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 16:04:47 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 16:04:47 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:04:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 16:04:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 16:04:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:06:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 16:06:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 16:06:25 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:07:21 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 16:07:21 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:07:52 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 74
ERROR - 2022-05-16 16:07:52 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 80
ERROR - 2022-05-16 16:08:24 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 16:28:43 --> Query error: Table 'ekattor_7.4.parent' doesn't exist - Invalid query: SELECT *
FROM `parent`
WHERE `id` IS NULL
ERROR - 2022-05-16 20:32:53 --> 404 Page Not Found: Superadmin/superadmin
ERROR - 2022-05-16 17:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Software\htdocs\ekattor_7.4\application\models\Crud_model.php 453
ERROR - 2022-05-16 17:09:28 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 17:09:28 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 17:09:28 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
ERROR - 2022-05-16 21:10:36 --> 404 Page Not Found: Online_admission/assigned
ERROR - 2022-05-16 17:11:20 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 67
ERROR - 2022-05-16 17:11:20 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 73
ERROR - 2022-05-16 17:11:20 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\profile.php 79
