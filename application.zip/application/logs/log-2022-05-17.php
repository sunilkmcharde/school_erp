<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-17 06:35:25 --> Severity: error --> Exception: syntax error, unexpected ')' E:\Software\htdocs\ekattor_7.4\application\controllers\Superadmin.php 1514
ERROR - 2022-05-17 06:35:29 --> Severity: error --> Exception: syntax error, unexpected ')' E:\Software\htdocs\ekattor_7.4\application\controllers\Superadmin.php 1514
ERROR - 2022-05-17 02:36:06 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:36:06 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:36:06 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:36:06 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:36:06 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:36:06 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:36:08 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\Software\htdocs\ekattor_7.4\system\libraries\Email.php 1902
ERROR - 2022-05-17 02:37:19 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:37:19 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:37:19 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:37:19 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:37:19 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:37:19 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:37:21 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\Software\htdocs\ekattor_7.4\system\libraries\Email.php 1902
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:38:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:42:13 --> Severity: Notice --> Undefined index: smtp_crypto E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:43:44 --> Query error: Unknown column 'smtp_crypto' in 'field list' - Invalid query: UPDATE `smtp_settings` SET `mail_sender` = 'generic_smtp', `smtp_protocol` = 'smtp', `smtp_host` = 'ssl://smtp.gmail.com', `smtp_crypto` = 'sd', `smtp_username` = 'Your email address', `smtp_password` = 'Email password', `smtp_port` = '465', `smtp_secure` = '', `smtp_set_from` = '', `smtp_show_error` = 'yes'
WHERE `id` = 1
ERROR - 2022-05-17 02:43:50 --> Query error: Unknown column 'smtp_crypto' in 'field list' - Invalid query: UPDATE `smtp_settings` SET `mail_sender` = 'generic_smtp', `smtp_protocol` = 'smtp', `smtp_host` = 'ssl://smtp.gmail.com', `smtp_crypto` = 'sd', `smtp_username` = 'Your email address', `smtp_password` = 'Email password', `smtp_port` = '465', `smtp_secure` = '', `smtp_set_from` = '', `smtp_show_error` = 'yes'
WHERE `id` = 1
ERROR - 2022-05-17 02:43:50 --> Query error: Unknown column 'smtp_crypto' in 'field list' - Invalid query: UPDATE `smtp_settings` SET `mail_sender` = 'generic_smtp', `smtp_protocol` = 'smtp', `smtp_host` = 'ssl://smtp.gmail.com', `smtp_crypto` = 'sd', `smtp_username` = 'Your email address', `smtp_password` = 'Email password', `smtp_port` = '465', `smtp_secure` = '', `smtp_set_from` = '', `smtp_show_error` = 'yes'
WHERE `id` = 1
ERROR - 2022-05-17 02:43:50 --> Query error: Unknown column 'smtp_crypto' in 'field list' - Invalid query: UPDATE `smtp_settings` SET `mail_sender` = 'generic_smtp', `smtp_protocol` = 'smtp', `smtp_host` = 'ssl://smtp.gmail.com', `smtp_crypto` = 'sd', `smtp_username` = 'Your email address', `smtp_password` = 'Email password', `smtp_port` = '465', `smtp_secure` = '', `smtp_set_from` = '', `smtp_show_error` = 'yes'
WHERE `id` = 1
ERROR - 2022-05-17 02:43:50 --> Query error: Unknown column 'smtp_crypto' in 'field list' - Invalid query: UPDATE `smtp_settings` SET `mail_sender` = 'generic_smtp', `smtp_protocol` = 'smtp', `smtp_host` = 'ssl://smtp.gmail.com', `smtp_crypto` = 'sd', `smtp_username` = 'Your email address', `smtp_password` = 'Email password', `smtp_port` = '465', `smtp_secure` = '', `smtp_set_from` = '', `smtp_show_error` = 'yes'
WHERE `id` = 1
ERROR - 2022-05-17 02:43:50 --> Query error: Unknown column 'smtp_crypto' in 'field list' - Invalid query: UPDATE `smtp_settings` SET `mail_sender` = 'generic_smtp', `smtp_protocol` = 'smtp', `smtp_host` = 'ssl://smtp.gmail.com', `smtp_crypto` = 'sd', `smtp_username` = 'Your email address', `smtp_password` = 'Email password', `smtp_port` = '465', `smtp_secure` = '', `smtp_set_from` = '', `smtp_show_error` = 'yes'
WHERE `id` = 1
ERROR - 2022-05-17 02:43:52 --> Severity: Notice --> Undefined index: smtp_crypto E:\Software\htdocs\ekattor_7.4\application\helpers\common_helper.php 80
ERROR - 2022-05-17 02:44:08 --> Query error: Unknown column 'smtp_crypto' in 'field list' - Invalid query: UPDATE `smtp_settings` SET `mail_sender` = 'generic_smtp', `smtp_protocol` = 'smtp', `smtp_host` = 'ssl://smtp.gmail.com', `smtp_crypto` = 'ssl', `smtp_username` = 'Your email address', `smtp_password` = 'Email password', `smtp_port` = '465', `smtp_secure` = '', `smtp_set_from` = '', `smtp_show_error` = 'yes'
WHERE `id` = 1
ERROR - 2022-05-17 02:46:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 20
ERROR - 2022-05-17 02:46:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 22
ERROR - 2022-05-17 02:46:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 24
ERROR - 2022-05-17 02:46:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 34
ERROR - 2022-05-17 02:46:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 36
ERROR - 2022-05-17 02:46:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 38
ERROR - 2022-05-17 02:46:27 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 38
ERROR - 2022-05-17 02:47:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 02:47:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 02:47:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 02:47:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 02:47:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 02:47:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 02:47:48 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 02:48:04 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 02:48:04 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 02:48:04 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 02:48:04 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 02:48:04 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 02:48:04 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 02:48:04 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:03:39 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\models\Email_model.php 117
ERROR - 2022-05-17 03:04:19 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\models\Email_model.php 117
ERROR - 2022-05-17 03:05:14 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\models\Email_model.php 117
ERROR - 2022-05-17 03:08:02 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\models\Email_model.php 117
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 21
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 23
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 25
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 35
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 37
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
ERROR - 2022-05-17 03:11:58 --> Severity: Notice --> Trying to access array offset on value of type null E:\Software\htdocs\ekattor_7.4\application\views\backend\superadmin\student\list.php 39
