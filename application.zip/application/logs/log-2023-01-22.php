<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:56:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:58:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 33
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 14:59:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 15:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\index.php 32
ERROR - 2023-01-22 16:48:07 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:48:07 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\latest_ekattor\application\helpers\common_helper.php 15
ERROR - 2023-01-22 16:48:12 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:48:12 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\latest_ekattor\application\helpers\common_helper.php 15
ERROR - 2023-01-22 16:48:14 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:48:14 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\latest_ekattor\application\helpers\common_helper.php 15
ERROR - 2023-01-22 16:48:20 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:48:20 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\latest_ekattor\application\helpers\common_helper.php 15
ERROR - 2023-01-22 16:48:36 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:48:40 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:48:45 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:49:23 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:49:37 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:50:35 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:51:41 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 16:51:45 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `class_id` = '1'
AND `id` = 1
ERROR - 2023-01-22 17:13:55 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\latest_ekattor\application\views\backend\student\attendance\index.php 55
ERROR - 2023-01-22 17:14:00 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\latest_ekattor\application\views\backend\student\attendance\index.php 55
ERROR - 2023-01-22 17:14:01 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\latest_ekattor\application\views\backend\student\attendance\index.php 55
ERROR - 2023-01-22 17:14:01 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\latest_ekattor\application\views\backend\student\attendance\index.php 55
ERROR - 2023-01-22 17:14:09 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\latest_ekattor\application\views\backend\student\attendance\index.php 55
ERROR - 2023-01-22 17:14:56 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\latest_ekattor\application\views\backend\student\routine\index.php 29
ERROR - 2023-01-22 17:15:28 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\latest_ekattor\application\views\backend\student\subject\index.php 29
ERROR - 2023-01-22 17:17:03 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\latest_ekattor\application\views\backend\student\syllabus\index.php 29
ERROR - 2023-01-22 17:17:29 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\latest_ekattor\application\views\backend\student\mark\index.php 39
ERROR - 2023-01-22 17:26:44 --> Severity: error --> Exception: Call to undefined function form_error() C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\single_student_admission.php 8
ERROR - 2023-01-22 17:26:47 --> Severity: error --> Exception: Call to undefined function form_error() C:\xampp\htdocs\latest_ekattor\application\views\backend\superadmin\student\single_student_admission.php 8
ERROR - 2023-01-22 14:11:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-01-22 14:24:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-01-22 14:24:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-01-22 19:52:59 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 57
ERROR - 2023-01-22 19:53:35 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 57
ERROR - 2023-01-22 19:55:24 --> Severity: error --> Exception: Class 'Section' not found C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 42
ERROR - 2023-01-22 19:56:49 --> Severity: error --> Exception: Class 'Section' not found C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 42
ERROR - 2023-01-22 20:01:43 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:01:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:01:43 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:01:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:01:43 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:01:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:02:31 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:02:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:02:31 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:02:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:02:31 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-22 20:02:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
