<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 41
ERROR - 2023-01-23 10:34:34 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 57
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 41
ERROR - 2023-01-23 10:55:07 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 57
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 32
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 41
ERROR - 2023-01-23 10:55:15 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 57
ERROR - 2023-01-23 11:02:07 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-23 11:02:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-23 11:02:07 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-23 11:02:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-23 11:02:07 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-23 11:02:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 45
ERROR - 2023-01-23 11:05:32 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 44
ERROR - 2023-01-23 11:05:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 44
ERROR - 2023-01-23 11:05:32 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 44
ERROR - 2023-01-23 11:05:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 44
ERROR - 2023-01-23 11:05:32 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 44
ERROR - 2023-01-23 11:05:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\latest_ekattor\application\views\backend\admin\student\index.php 44
ERROR - 2023-01-23 11:07:17 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `users` (`name`, `email`, `password`, `birthday`, `gender`, `blood_group`, `address`, `phone`, `role`, `school_id`, `watch_history`, `status`) VALUES (NULL, NULL, 'da39a3ee5e6b4b0d3255bfef95601890afd80709', 0, NULL, NULL, NULL, NULL, 'student', '1', '[]', '1')
ERROR - 2023-01-23 13:30:23 --> Severity: Warning --> copy(): Filename cannot be empty C:\xampp\htdocs\latest_ekattor\application\controllers\Updater.php 88
